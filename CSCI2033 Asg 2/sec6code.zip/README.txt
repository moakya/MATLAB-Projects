This is the current version of the code as of Wednesday, October 25.
